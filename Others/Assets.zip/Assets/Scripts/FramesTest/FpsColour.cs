﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class FpsColour
{
    public Color m_color;
    public int m_minimumFps;
}
