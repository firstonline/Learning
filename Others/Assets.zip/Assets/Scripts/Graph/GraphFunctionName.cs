﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum GraphFunctionName
{
	Sine,
	MultiSine,
	Sine2D,
	MultiSine2D,
	Ripple,
	Cylinder,
	Sphere,
	Torus
}
